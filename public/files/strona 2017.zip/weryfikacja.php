<?php

	session_start();
	if (isset($_POST['nick']))
	{
		//Udana walidacja? Załóżmy, że tak!
		$wszystko_OK=true;
		
		//Sprawdź poprawność nickname'a
		$nick = $_POST['nick'];
		
		//Sprawdzenie długości nicka
		if (!isset($_POST['nick']) || $_POST['nick']=='')
		{
			$wszystko_OK=false;
			$_SESSION['e_nick']="Podaj nick";
		}
		
		if (ctype_alnum($nick)==false)
		{
			$wszystko_OK=false;
			$_SESSION['e_nick']="Nick może składać się tylko z liter i cyfr (bez polskich znaków)";
		}
		
		$sekret = "6LeAkzgUAAAAACAdipYqH4alJe87oRt1zltI_ug2";
		
		$sprawdz = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$sekret.'&response='.$_POST['g-recaptcha-response']);
		
		$odpowiedz = json_decode($sprawdz);
		
		if ($odpowiedz->success==false)
		{
			$wszystko_OK=false;
			$_SESSION['e_bot']="Potwierdź, że nie jesteś botem!";
		}
		
		require_once "connect.php";
		mysqli_report(MYSQLI_REPORT_STRICT);
		
		try 
		{
			$polaczenie = new mysqli($host, $db_user, $db_password, $db_name);
			if ($polaczenie->connect_errno!=0)
			{
				throw new Exception(mysqli_connect_errno());
			}
			else
			{
				$rezultat = $polaczenie->query("SELECT Status FROM Players WHERE Name='$nick'");
				
				if (!$rezultat) throw new Exception($polaczenie->error);
				
				$ile_takich_maili = $rezultat->num_rows;
				if($ile_takich_maili>0)
				{
					$wszystko_OK=false;
					$_SESSION['e_nick']="Ten nick jest juz zweryfikowany";
				}		

				if ($wszystko_OK==true)
				{
					//Hurra, wszystkie testy zaliczone, dodajemy gracza do bazy
					
					if ($polaczenie->query("INSERT INTO Players VALUES ('$nick', 1)"))
					{
						$_SESSION['udanaweryfikacja']=true;
						header('Location: zweryfikowano');
					}
					else
					{
						throw new Exception($polaczenie->error);
					}
					
				}
				
				$polaczenie->close();
			}
			
		}
		catch(Exception $e)
		{
			echo '<span style="color:red;">Błąd serwera! Przepraszamy za niedogodności i prosimy o rejestrację w innym terminie!</span>';
			echo '<br />Informacja developerska: '.$e;
		}
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
	<title>MineBlock.pl</title>
	<meta name="description" content="Serwer skyblock MineBlock.pl"/>
	<meta name="keywords" content="serwer,minecraft,skyblock,mineblock,server,mineblock.pl"/>
	<link rel="stylesheet" href="style.css" type="text/css"/>
	<link rel="Shortcut icon" href="favicon.ico" />
	<script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>
<div id="header">
	<div id="menu">
		<a href="http://www.mineblock.pl">
		<img src="logo.png"/>
		</a>
		<div id="status">
			<?php require_once "online.php";
			require_once "status.php";
			if(isset($Info["players"]["online"])){
				echo ($Info["players"]["online"]);
			}
			else {
				echo (0);
			}
			echo "/";
			if(isset($Info["players"]["max"])){
				echo ($Info["players"]["max"] );
			}
			else {
				echo (0);
			}
			?>
		</div>
		</br>
		<ul id="menuul">
			<li><a href="http://www.mineblock.pl">Strona Główna</a></li>
			<li><a href="itemshop">Itemshop</a></li>
			<li><a href="administracja">Administracja</a></li>
			<li><a href="regulamin">Regulamin</a></li>
			<li><a href="weryfikacja">Weryfikacja</a></li>
			<li><a href="gracze">Gracze</a></li>
		</ul>
	</div>
</div>
<div style="clear:both;"></div>
<hr>
</br>
<div id="content">
<!--
<form method="post">
		Nick: <br /> <input type="text"  name="nick" /><br />
		<?php
			if (isset($_SESSION['e_nick']))
			{
				echo '<div class="error">'.$_SESSION['e_nick'].'</div>';
				unset($_SESSION['e_nick']);
			}
		?>
		<div class="g-recaptcha" data-sitekey="6LeAkzgUAAAAAF0WwwbAOi3crJYbL6TobwjZpG1a"></div>
		<?php
			if (isset($_SESSION['e_bot']))
			{
				echo '<div class="error">'.$_SESSION['e_bot'].'</div>';
				unset($_SESSION['e_bot']);
			}
		?>	
		<input type="submit" value="Zweryfikuj" />
		
	</form>
-->
<h2>Weryfikacja nieczynna do startu serwera</h2>
</div>
</body>