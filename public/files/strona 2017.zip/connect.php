<?php

	$host = "sql.pukawka.pl";
	$db_user = "653331";
	$db_password = "Q2YDC5KgyBOXrg";
	$db_name = "653331_antybot";
	
?>