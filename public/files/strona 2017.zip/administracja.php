<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
	<title>MineBlock.pl</title>
	<meta name="description" content="Serwer skyblock MineBlock.pl"/>
	<meta name="keywords" content="serwer,minecraft,skyblock,mineblock,server,mineblock.pl"/>
	<link rel="stylesheet" href="style.css" type="text/css"/>
	<link rel="Shortcut icon" href="favicon.ico" />
</head>
<body>
<div id="header">
	<div id="menu">
		<a href="http://www.mineblock.pl">
		<img src="logo.png"/>
		</a>
		<div id="status">
			<?php require_once "online.php";
			require_once "status.php";
			if(isset($Info["players"]["online"])){
				echo ($Info["players"]["online"]);
			}
			else {
				echo (0);
			}
			echo "/";
			if(isset($Info["players"]["max"])){
				echo ($Info["players"]["max"] );
			}
			else {
				echo (0);
			}
			?>
		</div>
		</br>
		<ul id="menuul">
			<li><a href="http://www.mineblock.pl">Strona Główna</a></li>
			<li><a href="itemshop">Itemshop</a></li>
			<li><a href="administracja">Administracja</a></li>
			<li><a href="regulamin">Regulamin</a></li>
			<li><a href="weryfikacja">Weryfikacja</a></li>
			<li><a href="gracze">Gracze</a></li>
		</ul>
	</div>
</div>
<div style="clear:both;"></div>
<hr>
</br>
<div id="content">
	<div class="glowa">
	</br>
	<img src="https://minotar.net/armor/body/demono10000/150.png"/>
	<center><font color="orange" size=5>demono10000</br></font>
	<font color="red">Właściciel</font></center>
	</div>
	<div class="glowa">
	</br>
	<img src="https://minotar.net/armor/body/kyosche/150.png"/>
	<center><font color="orange" size=5>Kyosche</br></font>
	<font color="red">Właściciel</font></center>
	</div>
</div>
</body>