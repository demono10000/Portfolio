<?php
 define( 'MQ_SERVER_ADDR', '185.38.248.80' );
 define( 'MQ_SERVER_PORT', 26418 );
 define( 'MQ_TIMEOUT', 1 );
 error_reporting(0);
 if($socket = fsockopen(gethostbyname(MQ_SERVER_ADDR), MQ_SERVER_PORT, $errno, $errstr, 10)) 
 {
	echo '<font color="#00cc00">Online </font>';
	fclose($socket);
}
 else {
	echo '<font color="red">Offline </font>';
 }
 //echo 'IP: '.gethostbyname(MQ_SERVER_ADDR).'<br>';
 //echo 'Port: '.MQ_SERVER_PORT.'<br>';
?>